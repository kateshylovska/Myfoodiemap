var numbers = 0;
for (numbers = 0; numbers<100; numbers++){
  numbers;
}
// if (numbers === 9){
//   numbers =  'Cat';
// }
// else if (numbers === 25){
//   numbers = 'Dog'
// }
// else if (numbers === 15){
//   numbers = 'CatDog'
// }
//
// console.log(numbers);

