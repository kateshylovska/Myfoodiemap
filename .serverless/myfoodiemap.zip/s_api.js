
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kates',
  applicationName: 'restaurants',
  appUid: 'xGpgfH58FPFMlL9g5y',
  orgUid: 'wFVjZ0F7dkJ5vCbCyn',
  deploymentUid: 'e0d767f3-bde7-40f5-9fb7-555168468399',
  serviceName: 'myfoodiemap',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'production',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.18',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'myfoodiemap-production-api', timeout: 10 };

try {
  const userHandler = require('./lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.universal, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}